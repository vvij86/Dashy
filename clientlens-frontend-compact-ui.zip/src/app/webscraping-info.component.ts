import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ButtonModule } from 'primeng/button';
import { FormsModule } from '@angular/forms';
import { environment } from './environments/environment';

type RowAny = Record<string, any>;

@Component({
  selector: 'app-webscraping-info',
  standalone: true,
  imports: [CommonModule, FormsModule, TableModule, DialogModule, InputTextModule, InputSwitchModule, ButtonModule],
  styles: [`
    .toolbar { display:flex; gap:.5rem; margin-bottom:1rem; align-items:center; }
    .w-100 { width:100%; }
    .minw { min-width: 120rem; }
  `],
  template: `
  <div class="toolbar">
    <button pButton label="Reload" icon="pi pi-refresh" (click)="load()"></button>
    <button pButton label="New" icon="pi pi-plus" (click)="openCreate()" class="p-button-success"></button>
  </div>

  <p-table
    styleClass="p-datatable-sm compact-table"
    [autoLayout]="true"
    [value]="rows"
    [columns]="cols"
    [scrollable]="true"
    scrollHeight="60vh"
    [resizableColumns]="true"
    [tableStyle]="{ 'min-width': '120rem' }"
    class="minw"
  >
    <ng-template pTemplate="colgroup" let-columns>
      <colgroup>
        <col *ngFor="let col of columns" [style.width]="col.width || null" [ngClass]="col.css"></col>
        <col class="action-col" />
      </colgroup>
    </ng-template>

    <ng-template pTemplate="header" let-columns>
      <tr>
        <th *ngFor="let col of columns" pResizableColumn>{{ col.header }}</th>
        <th style="width: 10rem">Actions</th>
      </tr>
    </ng-template>

    <ng-template pTemplate="body" let-row let-columns="columns">
      <tr>
        <td *ngFor="let col of columns">
          <ng-container [ngSwitch]="typeOf(row[col.field])">
            <p-inputSwitch *ngSwitchCase="'boolean'" [ngModel]="row[col.field]" [readonly]="true"></p-inputSwitch>
            <span *ngSwitchDefault>{{ row[col.field] }}</span>
          </ng-container>
        </td>
        <td>
          <button pButton icon="pi pi-pencil" label="Edit" size="small" (click)="openEdit(row)"></button>
          <button pButton icon="pi pi-trash" label="Delete" size="small" class="p-button-danger ml-2" (click)="remove(row)"></button>
        </td>
      </tr>
    </ng-template>
  </p-table>

  <p-dialog [(visible)]="dlgVisible" [modal]="true" [style]="{width:'40rem'}" [draggable]="false" [resizable]="false" [closable]="true" header="{{ editing ? 'Edit' : 'Create' }} Webscraping Info">
    <div class="p-fluid">
      <div class="field" *ngFor="let col of cols">
        <label class="block mb-2">{{ col.header }}</label>
        <ng-container [ngSwitch]="colTypes[col.field]">
          <input *ngSwitchCase="'string'" pInputText class="w-100" [(ngModel)]="form[col.field]"/>
          <input *ngSwitchCase="'number'" type="number" pInputText class="w-100" [(ngModel)]="form[col.field]"/>
          <p-inputSwitch *ngSwitchCase="'boolean'" [(ngModel)]="form[col.field]"></p-inputSwitch>
          <input *ngSwitchDefault pInputText class="w-100" [(ngModel)]="form[col.field]"/>
        </ng-container>
      </div>
    </div>
    <ng-template pTemplate="footer">
      <button pButton label="Cancel" class="p-button-text" (click)="dlgVisible=false"></button>
      <button pButton label="Save" (click)="save()"></button>
    </ng-template>
  </p-dialog>
  `
})
export class WebscrapingInfoComponent implements OnInit {
  rows: RowAny[] = [];
  cols: { field: string; header: string }[] = [];
  colTypes: Record<string, 'string'|'number'|'boolean'|'other'> = {};
  dlgVisible = false;
  editing = false;
  form: RowAny = {};

  constructor(private http: HttpClient) {}

  ngOnInit(){ this.load(); }

  typeOf(v: any): 'string'|'number'|'boolean'|'object'|'undefined' {
    const t = typeof v;
    if (t === 'string' || t === 'number' || t === 'boolean') return t as any;
    return 'object';
  }

  private toHeader(key: string): string {
    return key
      .replace(/_/g, ' ')
      .replace(/\b\w/g, (m: string) => m.toUpperCase());
  }

  private inferType(value: any): 'string'|'number'|'boolean'|'other' {
    const t = typeof value;
    if (t === 'string' || t === 'number' || t === 'boolean') return t as any;
    return 'other';
  }

  private buildColumns(sample: RowAny){
    this.cols = Object.keys(sample).map(k => {
      const header = this.toHeader(k);
      const t = this.inferType(sample[k]);
      const css = /(^is_|_flag$|_enabled$|_needed$)/i.test(k) || t==='boolean' ? 'bool-col' :
                  /(url|link)$/i.test(k) ? 'url-col' :
                  /(id$)/i.test(k) ? 'id-col' : 'text-col';
      const width = css==='bool-col' ? '7ch' : (css==='id-col' ? '10ch' : (css==='url-col' ? '40rem' : null));
      return { field: k, header, width, css } as any;
    });
    this.colTypes = {};
    for (const k of Object.keys(sample)) {
      this.colTypes[k] = this.inferType(sample[k]);
    }
  }

  load(){
    this.http.get<RowAny[]>(`${environment.apiBase}/webscraping-info`).subscribe((r: any) => {
      this.rows = r || [];
      if (this.rows.length) this.buildColumns(this.rows[0]);
    });
  }

  openCreate(){
    this.editing = false;
    this.form = {};
    if (this.cols.length){
      for (const c of this.cols){
        const t = this.colTypes[c.field] || 'string';
        this.form[c.field] = t === 'boolean' ? false : (t === 'number' ? 0 : '');
      }
      for (const key of Object.keys(this.form)){
        if (/id$/.test(key)) this.form[key] = undefined;
      }
    }
    this.dlgVisible = true;
  }

  openEdit(row: RowAny){
    this.editing = true;
    this.form = JSON.parse(JSON.stringify(row));
    this.dlgVisible = true;
  }

  save(){
    const idKey = this.cols.map(c => c.field).find(k => /id$/.test(k)) || 'webscraping_id';
    const id = this.form[idKey];
    if (this.editing && id != null){
      this.http.put(`${environment.apiBase}/webscraping-info/${id}`, this.form)
        .subscribe(() => { this.dlgVisible=false; this.load(); });
    } else {
      this.http.post(`${environment.apiBase}/webscraping-info`, this.form)
        .subscribe(() => { this.dlgVisible=false; this.load(); });
    }
  }

  remove(row: RowAny){
    const idKey = this.cols.map(c => c.field).find(k => /id$/.test(k)) || 'webscraping_id';
    const id = row[idKey];
    if (id == null){ return; }
    this.http.delete(`${environment.apiBase}/webscraping-info/${id}`)
      .subscribe(() => this.load());
  }
}
