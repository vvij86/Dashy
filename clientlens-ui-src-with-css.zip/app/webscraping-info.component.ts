import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ButtonModule } from 'primeng/button';
import { FormsModule } from '@angular/forms';
import { environment } from '../environments/environment';

type RowAny = Record<string, any>;

@Component({
  selector: 'app-webscraping-info',
  standalone: true,
  imports: [CommonModule, FormsModule, TableModule, DialogModule, InputTextModule, InputSwitchModule, ButtonModule],
  templateUrl: './webscraping-info.component.html',
  styleUrls: ['./webscraping-info.component.css'],
  })
export class WebscrapingInfoComponent implements OnInit {
  rows: RowAny[] = [];
  cols: { field: string; header: string; width?: string | null; css?: string }[] = [];
  formCols: { field: string; header: string; width?: string | null; css?: string }[] = [];
  colTypes: Record<string, 'string' | 'number' | 'boolean' | 'other'> = {};
  dlgVisible = false;
  editing = false;
  form: RowAny = {};
  submitted = false;

  constructor(private http: HttpClient) {}

  ngOnInit(): void { this.load(); }

  private toHeader(key: string): string {
    return key.replace(/_/g, ' ').replace(/\b\w/g, (m: string) => m.toUpperCase());
  }

  private inferType(value: any): 'string' | 'number' | 'boolean' | 'other' {
    const t = typeof value;
    if (t === 'string' || t === 'number' || t === 'boolean') return t as any;
    return 'other';
  }

  private buildColumns(sample: RowAny): void {
    this.cols = Object.keys(sample).map(k => {
      const header = this.toHeader(k);
      const t = this.inferType(sample[k]);
      const css =
        (/^(is_|has_)/i.test(k) || t === 'boolean') ? 'bool-col' :
        /(url|link)$/i.test(k) ? 'url-col' :
        (k.toLowerCase() === 'webscraping_id') ? 'id-col' : 'text-col';
      const width = css === 'bool-col' ? '7ch' : (css === 'id-col' ? '10ch' : (css === 'url-col' ? '40rem' : null));
      return { field: k, header, width, css };
    });
    // exclude only the identity column from the form
    this.formCols = this.cols.filter(c => c.field.toLowerCase() !== 'webscraping_id');
    this.colTypes = {};
    for (const k of Object.keys(sample)) {
      this.colTypes[k] = this.inferType(sample[k]);
    }
  }

  load(): void {
    this.http.get<RowAny[]>(`${environment.apiBase}/webscraping-info`).subscribe(r => {
      this.rows = r || [];
      if (this.rows.length) this.buildColumns(this.rows[0]);
    });
  }

  openCreate(): void {
    this.editing = false;
    this.form = {};
    if (this.cols.length) {
      for (const c of this.cols) {
        const t = this.colTypes[c.field] || 'string';
        this.form[c.field] = t === 'boolean' ? false : (t === 'number' ? 0 : '');
      }
      if ('webscraping_id' in this.form) this.form['webscraping_id'] = undefined;
    }
    if (!this.formCols.length) {
      const keys = Object.keys(this.form || {});
      this.formCols = keys.filter(k => k.toLowerCase() !== 'webscraping_id')
                          .map(k => ({ field: k, header: this.toHeader(k) }));
    }
    this.dlgVisible = true;
  }

  openEdit(row: RowAny): void {
    this.editing = true;
    this.form = JSON.parse(JSON.stringify(row));
    if (!this.cols.length) this.buildColumns(row);
    if (!this.formCols.length) {
      const keys = Object.keys(this.form || {});
      this.formCols = keys.filter(k => k.toLowerCase() !== 'webscraping_id')
                          .map(k => ({ field: k, header: this.toHeader(k) }));
    }
    this.dlgVisible = true;
  }

  onSubmit(frm: any): void {
    this.submitted = true;
    if (frm && frm.invalid) { return; }
    this.save();
  }

  save(): void {
    const idKey = this.cols.map(c => c.field).find(k => k.toLowerCase() === 'webscraping_id') || 'webscraping_id';
    const id = this.form[idKey];
    if (this.editing && id != null) {
      this.http.put(`${environment.apiBase}/webscraping-info/${id}`, this.form)
        .subscribe(() => { this.dlgVisible = false; this.load(); });
    } else {
      this.http.post(`${environment.apiBase}/webscraping-info`, this.form)
        .subscribe(() => { this.dlgVisible = false; this.load(); });
    }
  }

  remove(row: RowAny): void {
    const idKey = this.cols.map(c => c.field).find(k => k.toLowerCase() === 'webscraping_id') || 'webscraping_id';
    const id = row[idKey];
    if (id == null) { return; }
    this.http.delete(`${environment.apiBase}/webscraping-info/${id}`).subscribe(() => this.load());
  }

  typeOf(v: any): 'string' | 'number' | 'boolean' | 'object' | 'undefined' {
    const t = typeof v;
    if (t === 'string' || t === 'number' || t === 'boolean') return t as any;
    return 'object';
  }
}
