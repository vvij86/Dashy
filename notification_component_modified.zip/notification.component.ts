import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { environment } from '../app/environments/environment';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

interface EmailGroup {
  email_group: string;
  email_recipients?: string;
}

interface EmailNotification {
  email_content: string | null;
  email_subject: string | null;
  email_receiver: string | null;
  email_sender: string | null;
  email_date: string;
  email_group: string | null;
}

@Component({
  selector: 'app-notification',
  standalone: true,
  encapsulation: ViewEncapsulation.None,
  imports: [CommonModule, FormsModule, HttpClientModule, DropdownModule, TableModule, DialogModule],
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {
  // Dropdown
  selectedGroup: EmailGroup | null = null;

  // Caches
  allGroups: EmailGroup[] = [];
  loadingAll = false;

  // Notifications
  notifications: EmailNotification[] = [];
  allNotifications: EmailNotification[] = [];
  isLoading = false;
  loadError: string | null = null;
  private pendingGroup: string | null = null;
  dataLoaded = false;

  // Dialog
  displayDialog = false;
  selectedNotification: EmailNotification | null = null;

  constructor(private http: HttpClient, private sanitizer: DomSanitizer) {}

  ngOnInit(): void {
    this.preload();
    this.fetchAllNotifications();
  }

  private preload(): void {
    this.loadingAll = true;
    this.http.get<EmailGroup[]>(`${environment.apiBase}/email-groups`)
      .subscribe({
        next: list => {
          this.allGroups = list || [];
          this.loadingAll = false;
        },
        error: () => {
          this.loadingAll = false;
        }
      });
  }

  public normalizeGroup(g: string | null | undefined): string {
    return (g || '')
      .replace(/\u00A0/g, ' ')
      .trim()
      .replace(/\s{2,}/g, ' ')
      .toLowerCase();
  }

  private fetchAllNotifications(): void {
    self = this as any;
    this.isLoading = true;
    this.http.get<EmailNotification[]>(`${environment.apiBase}/email-notifications`)
      .subscribe({
        next: list => {
          this.allNotifications = (list || []).map(n => ({
            ...n,
            email_group: n.email_group ? n.email_group.replace(/\u00A0/g,' ').trim() : n.email_group
          }));
          this.isLoading = false;
          this.dataLoaded = true;

          if (this.pendingGroup) {
            this.applyGroupFilter(this.pendingGroup);
            this.pendingGroup = null;
          }
        },
        error: _ => {
          this.loadError = 'Failed to load notifications';
          this.isLoading = false;
          this.dataLoaded = true;
        }
      });
  }

  private extractGroups(raw: string | null): string[] {
    if (!raw) return [];
    return raw
      .split(/[;,]+/)
      .map(part => this.normalizeGroup(part))
      .filter(part => part.length > 0);
  }

  private applyGroupFilter(group: string): void {
    const target = this.normalizeGroup(group);
    const filtered = this.allNotifications.filter(n => {
      const groups = this.extractGroups(n.email_group);
      return groups.includes(target);
    });
    this.notifications = filtered;
  }

  // Called by p-dropdown (onChange)
  onGroupChange(ev: {originalEvent: Event, value: EmailGroup | null}) {
    if (!ev?.value) {
      // cleared
      this.selectedGroup = null;
      this.resetNotifications();
      return;
    }
    const grp = ev.value.email_group;
    if (!grp) return;

    if (!this.dataLoaded || this.isLoading) {
      this.pendingGroup = grp;
      return;
    }
    this.applyGroupFilter(grp);
  }

  clearSelection() {
    this.selectedGroup = null;
    this.resetNotifications();
  }

  resetNotifications() {
    this.notifications = [];
    this.loadError = null;
  }

  private rewriteForDark(html: string): string {
    if (!html) return '';
    let out = html;

    out = out.replace(/\sbgcolor\s*=\s*"(?:#ffffff|#fff|white)"/gi, '');
    out = out.replace(/\sbgcolor\s*=\s*'(?:#ffffff|#fff|white)'/gi, '');
    out = out.replace(/\sbgcolor\s*=\s*"[^"]*"/gi, '');
    out = out.replace(/\sbgcolor\s*=\s*'[^']*'/gi, '');

    const stripBg = (tag: string) => {
      const rx = new RegExp(`<${tag}([^>]*)style="([^"]*)"`, 'gi');
      out = out.replace(rx, (_m, attrs, style) => {
        const cleaned = style
          .replace(/background[^;"]*;?/gi, '')
          .replace(/background-color[^;"]*;?/gi, '')
          .replace(/color:\s*#000([^;}"]*)/gi, 'color:#e2e2e2$1')
          .replace(/color:\s*black([^;}"]*)/gi, 'color:#e2e2e2$1');
        return `<${tag}${attrs}style="${cleaned}"`;
      });
    };
    ['th','td','tr','table'].forEach(stripBg);

    out = out.replace(/style="([^"]*background[^"]*)"/gi, (m, style) => {
      const cleaned = style
        .replace(/background(?:-color)?\s*:\s*(#fff|#ffffff|white|#fdfdfd|#fafafa)\s*;?/gi, '')
        .replace(/color:\s*(#000|#000000|black)\s*;?/gi, 'color:#e2e2e2;');
      return `style="${cleaned}"`;
    });

    out = out.replace(/<body([^>]*)>/i, (m, attrs) => {
      const a = attrs.replace(/style="[^"]*"/gi, '');
      return `<body${a} style="background:#232529;color:#e2e2e2;">`;
    });

    const styleBlock = `
<style>
.email-dark-wrapper { background:#232529 !important; color:#e2e2e2 !important; }
.email-dark-wrapper table { border-collapse:collapse !important; width:100% !important; }
.email-dark-wrapper thead th { background:#34373c !important; color:#ffffff !important; border:1px solid #3f4349 !important; }
.email-dark-wrapper td { border:1px solid #3a3d42 !important; }
.email-dark-wrapper tr:nth-child(even) td { background:#2f3237 !important; }
.email-dark-wrapper tr:nth-child(odd) td { background:#292c31 !important; }
.email-dark-wrapper a { color:#62a8ff !important; }
</style>`.strip();

    if (!/class="email-dark-wrapper"/.test(out)) {
      out = `<div class="email-dark-wrapper">${styleBlock}${out}</div>`;
    } else {
      out = styleBlock + out;
    }
    return out;
  }

  safeHtml(html: string | null): SafeHtml {
    const transformed = this.rewriteForDark(html || '');
    return this.sanitizer.bypassSecurityTrustHtml(transformed);
  }

  showNotification(notification: EmailNotification): void {
    this.selectedNotification = notification;
    this.displayDialog = true;
  }
}