Run:
  nvm use 20
  rm -rf node_modules package-lock.json
  npm cache verify
  npm install
  npm start

Changes:
- Angular-friendly TS config (Bundler resolution)
- zone.js import in main.ts
- PrimeNG dynamic Webscraping table with pagination
- Compact UI + proper dialog layouts
- Labels in Client/Email dialogs, non-editable identity field in Webscraping form, action button spacing