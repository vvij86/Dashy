import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TabViewModule } from 'primeng/tabview';
import { ButtonModule } from 'primeng/button';
import { ClientInfoComponent } from './client-info.component';
import { EmailGroupComponent } from './email-group.component';
import { WebscrapingInfoComponent } from './webscraping-info.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, TabViewModule, ButtonModule, ClientInfoComponent, EmailGroupComponent, WebscrapingInfoComponent],
  templateUrl: './app.component.html',
})
export class AppComponent {}
