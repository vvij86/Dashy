import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { FormsModule } from '@angular/forms';
import { environment } from './environments/environment';

interface ClientInfo {
  client_name: string;
  client_full_name: string;
  client_sfid?: string;
  language?: string;
}

@Component({
  selector: 'app-client-info',
  standalone: true,
  imports: [CommonModule, TableModule, DialogModule, InputTextModule, ButtonModule, FormsModule],
  templateUrl: './client-info.component.html',
})
export class ClientInfoComponent implements OnInit {
  rows: ClientInfo[] = [];
  dlgVisible = false;
  editing = false;
  originalKey = '';
  form: ClientInfo = {client_name:'', client_full_name:'', client_sfid:'', language:''};

  submitted = false;
  constructor(private http: HttpClient) {}

  ngOnInit(){ this.load(); }

  load(){
    this.http.get<ClientInfo[]>(`${environment.apiBase}/client-info`).subscribe(r => this.rows = r);
  }

  openCreate(){
    this.editing = false;
    this.form = {client_name:'', client_full_name:'', client_sfid:'', language:''};
    this.dlgVisible = true;
  }

  openEdit(r: ClientInfo){
    this.editing = true;
    this.originalKey = r.client_name;
    this.form = JSON.parse(JSON.stringify(r));
    this.dlgVisible = true;
  }

  save(){
    if(this.editing){
      this.http.put<ClientInfo>(`${environment.apiBase}/client-info/${this.originalKey}`, this.form)
        .subscribe(() => { this.dlgVisible=false; this.load(); });
    }else{
      this.http.post<ClientInfo>(`${environment.apiBase}/client-info`, this.form)
        .subscribe(() => { this.dlgVisible=false; this.load(); });
    }
  }
}
