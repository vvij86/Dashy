import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ButtonModule } from 'primeng/button';
import { FormsModule } from '@angular/forms';
import { environment } from './environments/environment';

type RowAny = Record<string, any>;

@Component({
  selector: 'app-webscraping-info',
  standalone: true,
  imports: [CommonModule, FormsModule, TableModule, DialogModule, InputTextModule, InputSwitchModule, ButtonModule],
  styles: [`
    .toolbar { display:flex; gap:.5rem; margin-bottom:1rem; align-items:center; }
    .w-100 { width:100%; }
    .minw { min-width: 80rem; }
  `],
  templateUrl: './webscraping-info.component.html',
})
export class WebscrapingInfoComponent implements OnInit {
  rows: RowAny[] = [];
  cols: { field: string; header: string; width?: string | null; css?: string }[] = [];
  formCols: { field: string; header: string; width?: string | null; css?: string }[] = [];
  colTypes: Record<string, 'string'|'number'|'boolean'|'other'> = {};
  dlgVisible = false;
  editing = false;
  form: RowAny = {};
  submitted = false;

  private requiredFields = new Set(['website_url','client_name','webscraping_type']);
  private urlRegex = '^(https?:\\/\\/)[^\s]+$';

  isRequired(field: string){ return this.requiredFields.has(field); }
  getPattern(field: string){ return /(url|link)$/i.test(field) ? this.urlRegex : null; }
  getMin(field: string){ return /(depth|max)/i.test(field) ? 0 : null; }

  constructor(private http: HttpClient) {}

  ngOnInit(){ this.load(); }

  typeOf(v: any): 'string'|'number'|'boolean'|'object'|'undefined' {
    const t = typeof v;
    if (t === 'string' || t === 'number' || t === 'boolean') return t as any;
    return 'object';
  }

  private toHeader(key: string): string {
    return key.replace(/_/g, ' ').replace(/\b\w/g, (m: string) => m.toUpperCase());
  }

  private inferType(value: any): 'string'|'number'|'boolean'|'other' {
    const t = typeof value;
    if (t === 'string' || t === 'number' || t === 'boolean') return t as any;
    return 'other';
  }

  private buildColumns(sample: RowAny){
    this.cols = Object.keys(sample).map(k => {
      const header = this.toHeader(k);
      const t = this.inferType(sample[k]);
      const css = /(^is_|_flag$|_enabled$|_needed$)/i.test(k) || t==='boolean' ? 'bool-col' :
                  /(url|link)$/i.test(k) ? 'url-col' :
                  /(id$)/i.test(k) ? 'id-col' : 'text-col';
      const width = css==='bool-col' ? '7ch' : (css==='id-col' ? '10ch' : (css==='url-col' ? '40rem' : null));
      return { field: k, header, width, css };
    });
    this.formCols = this.cols.filter(c => !/id$/.test(c.field));
    this.colTypes = {};
    for (const k of Object.keys(sample)) {
      this.colTypes[k] = this.inferType(sample[k]);
    }
  }

  load(){
    this.http.get<RowAny[]>(`${environment.apiBase}/webscraping-info`).subscribe((r: any) => {
      this.rows = r || [];
      if (this.rows.length) this.buildColumns(this.rows[0]);
    });
  }

  openCreate(){
    this.editing = false;
    this.form = {};
    if (this.cols.length){
      for (const c of this.cols){
        const t = this.colTypes[c.field] || 'string';
        this.form[c.field] = t === 'boolean' ? false : (t === 'number' ? 0 : '');
      }
      for (const key of Object.keys(this.form)){
        if (/id$/.test(key)) this.form[key] = undefined;
      }
    }
    this.dlgVisible = true;
  }

  openEdit(row: RowAny){
    this.editing = true;
    this.form = JSON.parse(JSON.stringify(row));
    this.dlgVisible = true;
  }

  save(){
    const idKey = this.cols.map(c => c.field).find(k => /id$/.test(k)) || 'webscraping_id';
    const id = this.form[idKey];
    if (this.editing && id != null){
      this.http.put(`${environment.apiBase}/webscraping-info/${id}`, this.form)
        .subscribe(() => { this.dlgVisible=false; this.load(); });
    } else {
      this.http.post(`${environment.apiBase}/webscraping-info`, this.form)
        .subscribe(() => { this.dlgVisible=false; this.load(); });
    }
  }

  remove(row: RowAny){
    const idKey = this.cols.map(c => c.field).find(k => /id$/.test(k)) || 'webscraping_id';
    const id = row[idKey];
    if (id == null){ return; }
    this.http.delete(`${environment.apiBase}/webscraping-info/${id}`)
      .subscribe(() => this.load());
  }
}
