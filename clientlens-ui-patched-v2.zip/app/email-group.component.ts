// Email group component
