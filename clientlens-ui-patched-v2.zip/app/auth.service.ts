// Auth Service with BehaviorSubject
