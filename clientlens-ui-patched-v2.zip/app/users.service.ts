// Webscraping service with bulk update helper
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin, map } from 'rxjs';
import { API } from './api-urls';
import { WebScrapingInfo } from './models';

@Injectable({ providedIn: 'root' })
export class WebscrapingInfoService {
  private http = inject(HttpClient);

  list(): Observable<WebScrapingInfo[]> {
    return this.http.get<WebScrapingInfo[]>(API.webscrapingInfo);
  }

  update(id: number, patch: Partial<WebScrapingInfo>): Observable<WebScrapingInfo> {
    return this.http.patch<WebScrapingInfo>(`${API.webscrapingInfo}/${id}`, patch);
  }

  // If server doesn't have a bulk endpoint, do client-side fan-out
  bulkUpdate(ids: number[], patch: Partial<WebScrapingInfo>): Observable<WebScrapingInfo[]> {
    const calls = ids.map(id => this.update(id, patch));
    return forkJoin(calls);
  }
}
