// Client info component
