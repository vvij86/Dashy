// Interfaces for SsoUser, DashboardUser, and WebScrapingInfo

export type WebscrapingType = 'file' | 'content'; // 'file' = file monitoring, 'content' = webcontent monitoring

export interface WebScrapingInfo {
  id: number;
  client_name: string;
  site_name: string;
  start_url: string;
  ws_type: WebscrapingType;  // NEW: type of monitoring
  notify_enabled: boolean;   // enable/disable email notification
  skip_download: boolean;    // if true, skip file downloads (only meaningful for ws_type='file')
  created_at?: string;
  updated_at?: string;
}
