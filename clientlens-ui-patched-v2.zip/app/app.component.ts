import { Component } from '@angular/core';
import { WebscrapingInfoComponent } from './webscraping-info.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [WebscrapingInfoComponent],
  templateUrl: './app.component.html'
})
export class AppComponent {}
