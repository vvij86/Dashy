// API urls
export const API_BASE = '/api';
export const API = {
  webscrapingInfo: `${API_BASE}/webscraping-info`,
};
