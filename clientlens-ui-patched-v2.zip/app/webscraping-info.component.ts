// Webscraping info component with type filter and bulk actions
import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

// PrimeNG
import { TableModule } from 'primeng/table';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ButtonModule } from 'primeng/button';
import { TooltipModule } from 'primeng/tooltip';
import { ToastModule } from 'primeng/toast';
import { DropdownModule } from 'primeng/dropdown';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService, MessageService } from 'primeng/api';

import { WebscrapingInfoService } from './users.service';
import { WebScrapingInfo, WebscrapingType } from './models';

@Component({
  selector: 'app-webscraping-info',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule, TableModule, InputSwitchModule, ButtonModule, TooltipModule, ToastModule, DropdownModule, ConfirmDialogModule],
  providers: [MessageService, ConfirmationService],
  templateUrl: './webscraping-info.component.html'
})
export class WebscrapingInfoComponent {
  private api = inject(WebscrapingInfoService);
  private messages = inject(MessageService);
  private confirm = inject(ConfirmationService);

  loading = signal(false);
  rows = signal<WebScrapingInfo[]>([]);

  // type filter
  typeFilter = signal<'all' | WebscrapingType>('all');
  filteredRows = computed(() => {
    const t = this.typeFilter();
    const all = this.rows();
    return t === 'all' ? all : all.filter(r => r.ws_type === t);
  });

  // selections for bulk ops (work on filtered)
  selectedIds = signal<Set<number>>(new Set());

  ngOnInit() {
    this.refresh();
  }

  refresh() {
    this.loading.set(true);
    this.selectedIds.set(new Set());
    this.api.list().subscribe({
      next: (rows) => { this.rows.set(rows); this.loading.set(false); },
      error: (err) => {
        this.loading.set(false);
        console.error(err);
        this.messages.add({ severity: 'error', summary: 'Load failed', detail: 'Unable to fetch Webscraping Info' });
      }
    });
  }

  // Inline toggle handlers
  onToggleNotify(row: WebScrapingInfo) {
    const newVal = !row.notify_enabled;
    const prev = row.notify_enabled;
    row.notify_enabled = newVal;
    this.api.update(row.id, { notify_enabled: newVal }).subscribe({
      next: () => this.messages.add({ severity: 'success', summary: 'Updated', detail: `Email notifications ${newVal ? 'enabled' : 'disabled'}` }),
      error: (err) => {
        console.error(err);
        row.notify_enabled = prev;
        this.messages.add({ severity: 'error', summary: 'Update failed', detail: 'Could not update notify flag' });
      }
    });
  }

  onToggleSkip(row: WebScrapingInfo) {
    // Only applicable for file monitoring
    if (row.ws_type !== 'file') return;
    const newVal = !row.skip_download;
    const prev = row.skip_download;
    row.skip_download = newVal;
    this.api.update(row.id, { skip_download: newVal }).subscribe({
      next: () => this.messages.add({ severity: 'success', summary: 'Updated', detail: `Skip download ${newVal ? 'enabled' : 'disabled'}` }),
      error: (err) => {
        console.error(err);
        row.skip_download = prev;
        this.messages.add({ severity: 'error', summary: 'Update failed', detail: 'Could not update skip-download flag' });
      }
    });
  }

  // Row selection
  toggleSelect(id: number, checked: boolean) {
    const s = new Set(this.selectedIds());
    if (checked) s.add(id); else s.delete(id);
    this.selectedIds.set(s);
  }
  selectAllVisible(checked: boolean) {
    const s = new Set(this.selectedIds());
    this.filteredRows().forEach(r => checked ? s.add(r.id) : s.delete(r.id));
    this.selectedIds.set(s);
  }

  // Bulk operations apply to currently filtered rows & selection
  bulkEmail(enable: boolean) {
    const ids = [...this.selectedIds()];
    if (ids.length === 0) {
      this.messages.add({ severity: 'warn', summary: 'No rows selected', detail: 'Select one or more rows first.' });
      return;
    }
    this.confirm.confirm({
      header: `${enable ? 'Enable' : 'Disable'} Email for Selected`,
      message: `Apply to ${ids.length} selected entr${ids.length>1?'ies':'y'} in '${this.typeFilter()}' view?`,
      accept: () => {
        this.api.bulkUpdate(ids, { notify_enabled: enable }).subscribe({
          next: () => {
            // optimistic local update
            const map = new Map(this.rows().map(r => [r.id, r]));
            ids.forEach(id => { const r = map.get(id); if (r) r.notify_enabled = enable; });
            this.rows.set([...map.values()]);
            this.messages.add({ severity: 'success', summary: 'Email updated', detail: `Email ${enable ? 'enabled' : 'disabled'} for ${ids.length} item(s).` });
          },
          error: (err) => {
            console.error(err);
            this.messages.add({ severity: 'error', summary: 'Bulk update failed', detail: 'Email toggle failed.' });
          }
        });
      }
    });
  }

  bulkSkip(enable: boolean) {
    // Only meaningful for file view
    if (this.typeFilter() !== 'file') {
      this.messages.add({ severity: 'warn', summary: 'Not applicable', detail: 'Skip Download applies only to File Monitoring.' });
      return;
    }
    const ids = [...this.selectedIds()];
    if (ids.length === 0) {
      this.messages.add({ severity: 'warn', summary: 'No rows selected', detail: 'Select one or more rows first.' });
      return;
    }
    this.confirm.confirm({
      header: `${enable ? 'Enable' : 'Disable'} Skip Download for Selected`,
      message: `Apply to ${ids.length} selected entr${ids.length>1?'ies':'y'} in File Monitoring?`,
      accept: () => {
        this.api.bulkUpdate(ids, { skip_download: enable }).subscribe({
          next: () => {
            const map = new Map(this.rows().map(r => [r.id, r]));
            ids.forEach(id => { const r = map.get(id); if (r) r.skip_download = enable; });
            this.rows.set([...map.values()]);
            this.messages.add({ severity: 'success', summary: 'Skip Download updated', detail: `Skip Download ${enable ? 'enabled' : 'disabled'} for ${ids.length} item(s).` });
          },
          error: (err) => {
            console.error(err);
            this.messages.add({ severity: 'error', summary: 'Bulk update failed', detail: 'Skip Download toggle failed.' });
          }
        });
      }
    });
  }
}
