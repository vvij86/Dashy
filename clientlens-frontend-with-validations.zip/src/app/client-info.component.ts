import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { FormsModule } from '@angular/forms';
import { environment } from './environments/environment';

interface ClientInfo {
  client_name: string;
  client_full_name: string;
  client_sfid?: string;
  language?: string;
}

@Component({
  selector: 'app-client-info',
  standalone: true,
  imports: [CommonModule, TableModule, DialogModule, InputTextModule, ButtonModule, FormsModule],
  template: `
  <div class="card">
    <div class="toolbar">
      <button pButton label="Add" icon="pi pi-plus" (click)="openCreate()"></button>
      <button pButton label="Refresh" icon="pi pi-refresh" (click)="load()"></button>
    </div>
    <p-table [value]="rows" [paginator]="true" [rows]="10" [resizableColumns]="true" responsiveLayout="scroll">
      <ng-template pTemplate="header">
        <tr>
          <th pResizableColumn>Client Name</th>
          <th pResizableColumn>Full Name</th>
          <th pResizableColumn>SFID</th>
          <th pResizableColumn>Language</th>
          <th style="width:120px;"></th>
        </tr>
      </ng-template>
      <ng-template pTemplate="body" let-r>
        <tr>
          <td>{{r.client_name}}</td>
          <td>{{r.client_full_name}}</td>
          <td>{{r.client_sfid}}</td>
          <td>{{r.language}}</td>
          <td>
            <button pButton icon="pi pi-pencil" class="p-button-text" (click)="openEdit(r)"></button>
          </td>
        </tr>
      </ng-template>
    </p-table>
  </div>

  
  <p-dialog [(visible)]="dlgVisible" [modal]="true" [style]="{'width':'42rem'}" [contentStyle]="{'max-height':'70vh','overflow':'auto'}"
            [draggable]="false" [resizable]="false" [closable]="true" header="{{ editing ? 'Edit' : 'Create' }} Client">
    <form #frm=\"ngForm\" (ngSubmit)=\"onSubmit(frm)\">
    <div class=\"p-fluid\">
  <div class="field">
    <label class="form-label">Client Name</label>
    <input pInputText class="w-full" name="client_name" required [(ngModel)]="form.client_name" [readonly]="editing"/>
  </div>
  <div class="field">
    <label class="form-label">Full Name</label>
    <input pInputText class="w-full" name="client_full_name" required [(ngModel)]="form.client_full_name"/>
  </div>
  <div class="field">
    <label class="form-label">SFID</label>
    <input pInputText class="w-full" [(ngModel)]="form.client_sfid"/>
  </div>
  <div class="field">
    <label class="form-label">Language</label>
    <input pInputText class="w-full" name="language" required [(ngModel)]="form.language"/>
  </div>
</div>

    <ng-template pTemplate="footer">
      <button pButton label="Cancel" class="p-button-text" (click)="dlgVisible=false"></button>
      <button pButton label="Save" type="submit" [disabled]="frm.invalid"></button>
    </ng-template>
  </p-dialog>
        
  `
})
export class ClientInfoComponent implements OnInit {
  rows: ClientInfo[] = [];
  dlgVisible = false;
  editing = false;
  originalKey = '';
  form: ClientInfo = {client_name:'', client_full_name:'', client_sfid:'', language:''};

  submitted = false;
  constructor(private http: HttpClient) {}

  ngOnInit(){ this.load(); }

  load(){
    this.http.get<ClientInfo[]>(`${environment.apiBase}/client-info`).subscribe(r => this.rows = r);
  }

  openCreate(){
    this.editing = false;
    this.form = {client_name:'', client_full_name:'', client_sfid:'', language:''};
    this.dlgVisible = true;
  }

  openEdit(r: ClientInfo){
    this.editing = true;
    this.originalKey = r.client_name;
    this.form = JSON.parse(JSON.stringify(r));
    this.dlgVisible = true;
  }

  save(){
    if(this.editing){
      this.http.put<ClientInfo>(`${environment.apiBase}/client-info/${this.originalKey}`, this.form)
        .subscribe(() => { this.dlgVisible=false; this.load(); });
    }else{
      this.http.post<ClientInfo>(`${environment.apiBase}/client-info`, this.form)
        .subscribe(() => { this.dlgVisible=false; this.load(); });
    }
  }
}
