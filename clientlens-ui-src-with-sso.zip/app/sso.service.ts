import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_URLS } from './api-urls';

export interface SsoUser {
  displayName: string;
  email?: string;
  [k: string]: any;
}

@Injectable({ providedIn: 'root' })
export class SsoService {
  constructor(private http: HttpClient) {}
  getUserInfo(): Observable<SsoUser> {
    return this.http.get<SsoUser>(API_URLS.SSO_URL, { withCredentials: true });
  }
}
