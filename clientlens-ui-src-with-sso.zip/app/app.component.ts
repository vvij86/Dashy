import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from './auth.service';
import { Observable } from 'rxjs';
import type { SsoUser } from './sso.service';
import { AccessDeniedComponent } from './access-denied.component';
import { TabViewModule } from 'primeng/tabview';
import { ButtonModule } from 'primeng/button';
import { ClientInfoComponent } from './client-info.component';
import { EmailGroupComponent } from './email-group.component';
import { WebscrapingInfoComponent } from './webscraping-info.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [AccessDeniedComponent, CommonModule, TabViewModule, ButtonModule, ClientInfoComponent, EmailGroupComponent, WebscrapingInfoComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  user$!: Observable<SsoUser | null>;
  denied$!: Observable<boolean>;
  constructor(private auth: AuthService){ this.user$ = this.auth.user$; this.denied$ = this.auth.denied$; }
  user$!: Observable<SsoUser | null>;
  denied$!: Observable<boolean>;}
