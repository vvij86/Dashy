import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import type { SsoUser } from './sso.service';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private _user$ = new BehaviorSubject<SsoUser | null>(null);
  private _denied$ = new BehaviorSubject<boolean>(false);

  readonly user$ = this._user$.asObservable();
  readonly denied$ = this._denied$.asObservable();

  get user(): SsoUser | null { return this._user$.value; }
  get denied(): boolean { return this._denied$.value; }

  setUser(u: SsoUser | null){ this._user$.next(u); }
  setDenied(v: boolean){ this._denied$.next(v); }
}
