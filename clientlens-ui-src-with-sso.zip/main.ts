function initAuth(auth: AuthService, sso: SsoService){return ()=>new Promise<void>((resolve)=>{sso.getUserInfo().subscribe({next:(u)=>{auth.setUser(u);resolve();},error:()=>{auth.setDenied(true);auth.setUser(null);resolve();}});});}
import 'zone.js';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient, withFetch } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';
import { AppComponent } from './app/app.component';
import { AuthService } from './app/auth.service';
import { SsoService } from './app/sso.service';

bootstrapApplication(AppComponent, {
  providers: [
      { provide: APP_INITIALIZER, useFactory: initAuth, deps: [AuthService, SsoService], multi: true },
    provideHttpClient(withFetch()),
    provideAnimations(),
  ]
}).catch(err => console.error(err));
