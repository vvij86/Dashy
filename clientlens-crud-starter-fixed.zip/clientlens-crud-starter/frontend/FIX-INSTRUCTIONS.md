# Frontend Fix Instructions (Angular 19 + PrimeNG)

1) Use Node 20.x (LTS)
   - `nvm use 20`

2) Clean install
   - `rm -rf node_modules package-lock.json`
   - `npm cache verify`
   - `npm install`

3) Start
   - `npm start`

Notes:
- `tsconfig.json` now uses `"moduleResolution": "Bundler"` and `"module": "ES2022"`.
- All components are standalone and imported via `AppComponent.imports`.
- `main.ts` provides HttpClient and animations via `bootstrapApplication` providers.
- PrimeNG + PrimeIcons + PrimeFlex are listed in `package.json` and styles are referenced in `angular.json`.